import { useNavigate } from "react-router-dom";
import { useState } from "react";
import { Eye, EyeOff } from "lucide-react";
import blue from "./../../assets/blue.jpg";
import { API_URL } from "../../lib/api";
import logo from "./../../assets/logonirtuto.png";


const Login = () => {
  const [email, setEmail] = useState("");
  const [mdp, setMdp] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async (e: { preventDefault: () => void; }) => {
    e.preventDefault();
    try {
      const res = await fetch(`${API_URL}/logins`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "Accept": "application/json" },
        body: JSON.stringify({ email, mdp }),
      });

      const data = await res.json();

      if (!res.ok) alert(data.message || "Email ou mot de passe incorrect");
      else {
        localStorage.setItem("token", data.token);
        localStorage.setItem("adminNom", data.user.nom);
        localStorage.setItem("adminRole", data.user.role);
        if (localStorage.getItem("adminRole") === "admin") navigate("/admin/dashboard");
        else if (localStorage.getItem("adminRole") === "formateur") navigate("/admin/formateur");
      }
    } catch (err) {
      console.error(err);
      alert("Erreur réseau");
    }
  };

  return (
    <div 
      className="flex justify-center items-center w-screen h-screen bg-cover bg-center bg-no-repeat animate-[brightness_2s_ease-in-out]"
      style={{ backgroundImage: `url(${blue})` }}
    >
      <form 
        className="w-[450px] p-10 bg-white/95 rounded-2xl shadow-[0_20px_40px_rgba(0,0,0,0.25)] text-center"
        onSubmit={handleLogin}
      >
        <div className="flex items-center justify-center mb-5"><img src={logo} className="w-52" /></div>
        <div className="w-full bg-black h-1 mb-5"></div>
        <h2 className="mb-6 text-2xl font-bold text-[#0f172a]">Connexion</h2>

        {/* Champ Email */}
        <input 
          type="email" 
          placeholder="Email" 
          name="email" 
          onChange={e => setEmail(e.target.value)} 
          className="w-full px-3.5 py-3 mb-4 rounded-lg border border-[#cbd5e1] outline-none focus:border-[#1e40af] text-sm"
          required
        />

        {/* Champ Mot de passe avec Oeil */}
        <div className="relative mb-4">
          <input 
            type={showPassword ? "text" : "password"} 
            placeholder="Mot de passe" 
            name="mdp" 
            onChange={e => setMdp(e.target.value)} 
            className="w-full px-3.5 py-3 rounded-lg border border-[#cbd5e1] outline-none focus:border-[#1e40af] text-sm"
            required
          />
          <button
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-[#1e3a8a] transition-colors"
          >
            {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
          </button>
        </div>

        <button 
          type="submit" 
          className="w-full p-3 bg-[#1e3a8a] text-white rounded-lg text-[15px] cursor-pointer transition-all hover:-translate-y-0.5 hover:shadow-[0_10px_20px_rgba(0,0,0,0.2)]"
        >
          Se connecter
        </button>
      </form>
    </div>
  );
};

export default Login;