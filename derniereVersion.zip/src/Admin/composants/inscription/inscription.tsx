import { useNavigate } from "react-router-dom";
import { useState } from "react";
import { Eye, EyeOff } from "lucide-react";
import { API_URL } from "./../../lib/api";
import blue from "./../../assets/blue.jpg";
import logo from "./../../assets/logonirtuto.png";


const Signup = () => {
  const [nom, setName] = useState("");
  const [contact, setContact] = useState("");
  const [email, setEmail] = useState("");
  const [mdp, setMdp] = useState("");
  const [cmdp, setCmdp] = useState("");
  
  // États pour la visibilité des mots de passe
  const [showMdp, setShowMdp] = useState(false);
  const [showCmdp, setShowCmdp] = useState(false);

  const navigate = useNavigate();

  const handleSubmit = async (e: { preventDefault: () => void; }) => {
    e.preventDefault();

    if (mdp !== cmdp) {
      alert("Les mots de passe ne correspondent pas");
      return;
    }

    const payload = { nom, contact, email, mdp, cmdp };

    try {
      const res = await fetch(`${API_URL}/registers`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "Accept": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await res.json();

      if (!res.ok) alert(data.message || "Erreur inscription");
      else {
        navigate("/admin/dashboard");
      }
    } catch (err) {
      console.error(err);
      alert("Erreur réseau");
    }
  };

  return (
    <div 
      className="flex justify-center items-center w-screen h-screen bg-cover bg-center bg-no-repeat animate-[brightness_2s_ease-in-out]"
      style={{ backgroundImage: `url(${blue})` }}
    >
      <form 
        className="w-[500px] p-10 bg-white/95 flex items-center flex-col rounded-2xl shadow-[0_20px_40px_rgba(0,0,0,0.25)] text-center"
        onSubmit={handleSubmit}
      >
        <img src={logo} className="w-40 h-16 text-center mb-4" />
        <div className="w-[420px] h-[2px] bg-black mb-4" />
        <h2 className="mb-6 text-2xl font-bold text-[#0f172a]">Ajout formateur</h2>

        {/* Champs standards */}
        <input 
          type="text" placeholder="Nom et Prenom" 
          onChange={e => setName(e.target.value)}
          className="w-full px-3.5 py-3 mb-4 rounded-lg border border-[#cbd5e1] outline-none focus:border-[#1e40af] text-sm"
          required
        />
        <input 
          type="tel" placeholder="Contact" 
          onChange={e => setContact(e.target.value)}
          className="w-full px-3.5 py-3 mb-4 rounded-lg border border-[#cbd5e1] outline-none focus:border-[#1e40af] text-sm"
          required
        />
        <input 
          type="email" placeholder="Email" 
          onChange={e => setEmail(e.target.value)}
          className="w-full px-3.5 py-3 mb-4 rounded-lg border border-[#cbd5e1] outline-none focus:border-[#1e40af] text-sm"
          required
        />

        {/* Mot de passe */}
        <div className="relative mb-4 w-full">
          <input 
            type={showMdp ? "text" : "password"} 
            placeholder="Mot de passe" 
            onChange={e => setMdp(e.target.value)}
            className="w-full px-3.5 py-3 rounded-lg border border-[#cbd5e1] outline-none focus:border-[#1e40af] text-sm"
            required
          />
          <button
            type="button"
            onClick={() => setShowMdp(!showMdp)}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-[#1e3a8a]"
          >
            {showMdp ? <EyeOff size={18} /> : <Eye size={18} />}
          </button>
        </div>

        {/* Confirmation Mot de passe */}
        <div className="relative mb-4 w-full">
          <input 
            type={showCmdp ? "text" : "password"} 
            placeholder="Confirmation mot de passe" 
            onChange={e => setCmdp(e.target.value)}
            className="w-full px-3.5 py-3 rounded-lg border border-[#cbd5e1] outline-none focus:border-[#1e40af] text-sm"
            required
          />
          <button
            type="button"
            onClick={() => setShowCmdp(!showCmdp)}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-[#1e3a8a]"
          >
            {showCmdp ? <EyeOff size={18} /> : <Eye size={18} />}
          </button>
        </div>

        <button 
          type="submit" 
          className="w-full p-3 bg-[#1e3a8a] text-white rounded-lg text-[15px] font-medium transition-all hover:-translate-y-0.5 hover:shadow-[0_10px_20px_rgba(0,0,0,0.2)] active:scale-95"
        >
          Ajouter
        </button>
      </form>
    </div>
  );
};

export default Signup;