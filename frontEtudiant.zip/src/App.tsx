import './App.css';
import { BrowserRouter as Router, Routes, Route, Navigate} from "react-router-dom";
import Connexion from './screen/Connexion';
import Profile from './screen/page/Profil/Profile';
import Exemple from './screen/page/DashboardEtudiant/DashboardEtud';
import Message from './screen/page/Message/Message';
import Formations from "./screen/page/Formation/Formations";
import Guide from "./screen/page/Guide/Guide";
import Facture from "./screen/page/Facture/Facture";
import Certification from "./screen/page/Certification/Certification";
import DetailFormation from "./screen/page/Formation/DetailFormation/detailFormation";
import GuideDetail from './screen/page/Guide/GuideDetail';
import { PublicRoute, ProtectedRoute } from './screen/protection/Protected';
import CourseList from "./screen/page/CoursList";
import PlayerPage from "./screen/page/Formation/PlayerPage";
import Home from './accueil/pages/Home';
import PageProjets from './accueil/pages/Formations/Pageprojet/PageProjets';
import PageMentors from './accueil/pages/Formations/PageMentors';
import PageCertifs from './accueil/pages/Formations/PageCertifs';
import PageBlogListe from './accueil/pages/Apropos/PageBlogListe';
import DetailBlog from './accueil/pages/Apropos/DetailsBlog';
import CatalogueFormation from './accueil/components/Formation/CatalogueFormation/CatalogueFormation';
import DetailsFormations from './accueil/components/Formation/DetailsFormations/DetailsFormations';
import VoirTousF from './accueil/pages/VoirTousFormations/VoirTousF';

function App() {
  return (
    <div className="w-full min-h-screen bg-white dark:bg-slate-900 text-slate-900 dark:text-white transition-colors duration-300">
    <Router>
      <Routes>
        <Route path="/" element={<PublicRoute><Home /></PublicRoute>} />        
        <Route path="/formations/projets" element={<PublicRoute><PageProjets /></PublicRoute>} />
        <Route path="/formations/mentors" element={<PublicRoute><PageMentors /></PublicRoute>} />
        <Route path="/formations/certifications" element={<PublicRoute><PageCertifs /></PublicRoute>} />
        <Route path="/blog" element={<PublicRoute><PageBlogListe /></PublicRoute>} />
        <Route path="/blog/:id" element={<PublicRoute><DetailBlog /></PublicRoute>} />
        <Route path="/formation/:id" element={<PublicRoute><DetailsFormations /></PublicRoute>} />
        <Route path="/formation/:id" element={<PublicRoute>
          <CatalogueFormation 
            activeTab="all" 
            setActiveTab={() => {}} 
            searchTerm="" 
            setSearchTerm={() => {}} 
            onSelectFormation={(f) => {}} // Sera géré en interne
          /></PublicRoute>
        } />
        <Route path="/voir-toutes-formations" element={<VoirTousF />} />
      

        <Route path="/connexion" element={<PublicRoute><Connexion /></PublicRoute>} />
        <Route path='/profil' element={<ProtectedRoute><Profile /></ProtectedRoute>} />
        <Route path="/dash" element={<ProtectedRoute><Exemple /></ProtectedRoute>}/>
        <Route path="/*" element={<Navigate to='/dash'/> }/>
        <Route path="/message" element={<ProtectedRoute><Message /></ProtectedRoute>}/>
        <Route path="/formations" element={<ProtectedRoute><Formations /></ProtectedRoute>} />
        <Route path="/guides" element={<ProtectedRoute><Guide /></ProtectedRoute>}/>
        <Route path="/facture" element={<ProtectedRoute><Facture /></ProtectedRoute>} />
        <Route path="/certification" element={<ProtectedRoute><Certification /></ProtectedRoute>} />
        <Route path="/detailformation/:id" element={<ProtectedRoute><DetailFormation /></ProtectedRoute>} />
        <Route path="/cour/:id" element={<ProtectedRoute><CourseList /></ProtectedRoute>} />
        <Route path="/player/:coursId" element={<ProtectedRoute><PlayerPage /></ProtectedRoute>} />
        <Route path="/playerguide/:guideId" element={<ProtectedRoute><GuideDetail/></ProtectedRoute>} />
      </Routes>
    </Router>
    </div>
  );
}

export default App;
