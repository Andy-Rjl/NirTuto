// Inscription.tsx
import { useState } from "react";
import { X, CheckCircle, AlertCircle, Mail } from "lucide-react";
import { API_URL } from "../../lib/api";
import { useNavigate } from "react-router-dom";
import ChoixFormation from "./ChoixFormation";
import logo from "../../assets/images/logo-nir-info.png";

interface FormationType {
  id: number;
  titre: string;
  nom_formateur: string;
  frais: number | null;
  type: string;
}

interface Props {
  formation: FormationType;
  onClose: () => void;
}
interface FormationsProps {
  searchTerm: string;
  setSearchTerm: (v: string) => void;
}

/* ── Alerte Vérification de l'E-mail ── */
interface VerifyProps {
  email: string;
  onClose: () => void;
  onVerifySubmit: (code: string, setError: (msg: string) => void, setLoading: (b: boolean) => void) => void;
}

const VerificationEmailAlert = ({ email, onClose, onVerifySubmit }: VerifyProps) => {
  const [code, setCode] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    
    if (code.length !== 6) {
      return setError("Le code doit contenir 6 chiffres.");
    }

    setLoading(true);
    // On transmet le code et les gestionnaires d'état au composant parent
    onVerifySubmit(code, setError, setLoading);
  };

  return (
    <>
      <div
        className="fixed inset-0 z-[300] flex items-center justify-center"
        style={{ backgroundColor: "rgba(0,0,0,0.45)", backdropFilter: "blur(4px)" }}
        onClick={onClose}
      >
        <div
          className="relative bg-white rounded-[2rem] shadow-2xl flex flex-col items-center px-6 py-8 mx-4 w-full max-w-[360px]"
          style={{ animation: "successIn 0.35s cubic-bezier(.34,1.56,.64,1) both" }}
          onClick={(e) => e.stopPropagation()}
        >
          <button onClick={onClose} className="absolute top-4 right-4 text-gray-300 hover:text-gray-500">
            <X size={16} />
          </button>
          
          <div className="flex items-center justify-center rounded-full mb-4"
            style={{ width: 64, height: 64, background: "linear-gradient(135deg,#818cf8,#5a4fcf)", boxShadow: "0 8px 24px rgba(90,79,207,0.3)" }}>
            <Mail size={28} color="white" />
          </div>
          
          <h2 className="text-gray-900 text-lg font-black mb-1 text-center">Vérifiez votre e-mail</h2>
          <p className="text-gray-400 text-xs text-center leading-relaxed mb-6">
            Un e-mail de validation contenant un code de sécurité a été envoyé à <strong className="text-gray-600 break-all">{email}</strong>.
          </p>

          <form onSubmit={handleVerify} className="w-full space-y-4">
            <input
              type="text"
              maxLength={6}
              placeholder="Code à 6 chiffres"
              value={code}
              onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))}
              className="w-full bg-gray-50 border border-gray-200 rounded-xl p-3 text-center text-lg outline-none focus:border-[#5a4fcf] focus:bg-white tracking-[0.3em] font-bold"
              required
            />
            
            {error && <p className="text-red-500 text-xs text-center font-medium">{error}</p>}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-[#5a4fcf] hover:bg-[#493dbb] text-white rounded-xl text-xs font-black uppercase tracking-wider transition-all"
            >
              {loading ? "Vérification..." : "Vérifier le code"}
            </button>
          </form>
        </div>
      </div>
    </>
  );
};

/* ── Alerte succès ── */
const SuccessAlert = ({ onClose, onContinue }: { onClose: () => void; onContinue: () => void }) => (
  <>
    <div
      className="fixed inset-0 z-[300] flex items-center justify-center"
      style={{ backgroundColor: "rgba(0,0,0,0.35)", backdropFilter: "blur(4px)" }}
      onClick={onClose}
    >
      <div
        className="relative bg-white rounded-[2rem] shadow-2xl flex flex-col items-center px-8 py-10 mx-4"
        style={{ width: "100%", maxWidth: 320, animation: "successIn 0.35s cubic-bezier(.34,1.56,.64,1) both" }}
        onClick={(e) => e.stopPropagation()}
      >
        <button onClick={onClose} className="absolute top-4 right-4 text-gray-300 hover:text-gray-500">
          <X size={14} />
        </button>
        <div className="flex items-center justify-center rounded-full mb-6"
          style={{ width: 72, height: 72, background: "linear-gradient(135deg,#6ee7a0,#34c471)", boxShadow: "0 8px 24px rgba(52,196,113,0.35)" }}>
          <CheckCircle size={34} color="white" />
        </div>
        <h2 className="text-gray-900 text-xl font-bold mb-2 text-center">Inscription réussie !</h2>
        <p className="text-gray-400 text-sm text-center leading-relaxed mb-8">
          Votre demande d'inscription a bien été envoyée. Elle sera validée prochainement.
        </p>
        <button
          onClick={onContinue}
          className="w-full py-3 rounded-2xl text-sm font-semibold border-2 border-gray-200 text-gray-500 transition-all hover:border-[#34c471] hover:text-[#34c471]"
        >
          Continuer
        </button>
      </div>
    </div>
    <style>{`@keyframes successIn{from{opacity:0;transform:scale(.85) translateY(16px)}to{opacity:1;transform:scale(1) translateY(0)}}`}</style>
  </>
);

/* ── Modal principale ── */
export default function Inscription({ formation: initialFormation, onClose, searchTerm, setSearchTerm }: Props & FormationsProps) {
  const navigate = useNavigate();

  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [selectedFormation, setSelectedFormation] = useState<FormationType>(initialFormation);
  const [tempSelection, setTempSelection] = useState<FormationType | null>(null);

  const [showPwd, setShowPwd] = useState(false);
  const [showPwd1, setShowPwd1] = useState(false);
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [showVerifyModal, setShowVerifyModal] = useState(false);
  const [dejaInscrit, setDejaInscrit] = useState(false);

  // Auth fields
  const [nom, setNom] = useState("");
  const [prenom, setPrenom] = useState("");
  const [contact, setContact] = useState("");
  const [email1, setEmail1] = useState("");
  const [mdp1, setMdp1] = useState("");
  const [cmdp1, setCmdp1] = useState("");

  const [activeTab, setActiveTab] = useState("all");

  // Paiement
  const [paymentData, setPaymentData] = useState({
    numero_paiement: "",
    reference_transaction: "",
    methode: "Mvola",
  });

  const isGratuit = !selectedFormation.frais || selectedFormation.frais === 0 || selectedFormation.type === "Gratuite";

  /* ── Vérifier si déjà inscrit ── */
  const verifierInscription = async (token: string): Promise<boolean> => {
    try {
      const res = await fetch(`${API_URL}/user/check-training?formation_id=${selectedFormation.id}`, {
        headers: {
          Accept: "application/json",
          Authorization: `Bearer ${token}`,
        },
      });
      if (!res.ok) return false;
      const data = await res.json();
      return data.has_training === true;
    } catch {
      return false;
    }
  };

  /* ── Après authentification et code d'e-mail validés ── */
  const afterAuth = async (token: string) => {
    const dejainscrit = await verifierInscription(token);
    setDejaInscrit(dejainscrit);

    if (dejainscrit) {
      setStep(3);
      return;
    }

    if (isGratuit) {
      await inscrireGratuit(token);
    } else {
      setStep(3);
    }
  };

  /* ── Étape 1 : Demande d'envoi du code (sans créer le compte) ── */
  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (mdp1 !== cmdp1) return setError("Les mots de passe ne correspondent pas");
    setSubmitting(true);
    try {
      // Appel à la route /pre-register qui envoie uniquement le code
      const res = await fetch(`${API_URL}/pre-register`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify({ nom, prenom, contact, email: email1, mdp: mdp1, cmdp: cmdp1 }),
      });
      const data = await res.json();
      if (!res.ok) return setError(data.message || "Erreur lors de la validation");
      
      // On ouvre la modale de saisie du code à 6 chiffres
      setShowVerifyModal(true);

    } catch { 
      setError("Erreur réseau ou serveur inaccessible"); 
    } finally { 
      setSubmitting(false); 
    }
  };

  /* ── Étape Finale : Soumission du code reçu par mail et création du compte final ── */
  const handleFinalVerification = async (code: string, setModalError: (msg: string) => void, setModalLoading: (b: boolean) => void) => {
    try {
      // On soumet le code et la totalité du formulaire à /verify-register
      const res = await fetch(`${API_URL}/verify-register`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify({ nom, prenom, contact, email: email1, mdp: mdp1, code }),
      });
      
      const data = await res.json();
      
      if (!res.ok) {
        setModalLoading(false);
        return setModalError(data.message || "Le code est invalide ou expiré.");
      }

      // Succès ! L'utilisateur est maintenant inséré dans la base de données
      setShowVerifyModal(false);
      localStorage.setItem("token", data.access_token);
      localStorage.setItem("user", JSON.stringify(data.user));
      
      // Suite logique du processus métier
      await afterAuth(data.access_token);

    } catch {
      setModalLoading(false);
      setModalError("Erreur réseau lors de la validation définitive.");
    }
  };

  /* ── Inscription gratuite ── */
  const inscrireGratuit = async (token?: string) => {
    const t = token ?? localStorage.getItem("token") ?? "";
    setSubmitting(true);
    try {
      const res = await fetch(`${API_URL}/inscrire`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
          Authorization: `Bearer ${t}`,
        },
        body: JSON.stringify({
          formation_id: selectedFormation.id,
          numero_paiement: "GRATUIT",
          reference_transaction: `GRATUIT-${selectedFormation.id}-${Date.now()}`,
          methode: "Gratuit",
        }),
      });
      const data = await res.json();
      if (res.ok) { setShowSuccess(true); }
      else setError(data.message || JSON.stringify(data.errors));
    } catch { setError("Erreur réseau"); }
    finally { setSubmitting(false); }
  };

  /* ── Inscription payante ── */
  const handleInscriptionSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await fetch(`${API_URL}/inscrire`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
        body: JSON.stringify({ formation_id: selectedFormation.id, ...paymentData }),
      });
      const data = await res.json();
      if (res.ok) { setShowSuccess(true); }
      else setError(data.message || JSON.stringify(data.errors));
    } catch { setError("Erreur réseau"); }
    finally { setSubmitting(false); }
  };

  /* ── Action du bouton Continuer de l'étape 1 ── */
  const handleConfirmFormation = () => {
    if (tempSelection) {
      setSelectedFormation(tempSelection);
      setStep(2);
    }
  };

  const getPasswordStrength = (password: string) => {
    if (!password) return { score: 0, label: "", color: "bg-gray-200" };
    let score = 0;
    if (password.length > 6) score++;
    if (/[A-Z]/.test(password)) score++;
    if (/[0-9]/.test(password)) score++;
    if (/[^A-Za-z0-9]/.test(password)) score++;

    if (score <= 1) return { score, label: "Faible", color: "bg-red-500" };
    if (score <= 3) return { score, label: "Moyen", color: "bg-orange-500" };
    return { score, label: "Fort", color: "bg-green-500" };
  };

  const strength = mdp1 ? getPasswordStrength(mdp1) : null;

  /* ── Stepper ── */
  const Stepper = () => (
    <div className="flex items-center mb-6 mx-24">
      {[1, 2, 3].map((n, i) => (
        <div key={n} className="flex items-center flex-1 last:flex-none">
          <div className="flex flex-col items-center">
            <div className={`w-11 h-11 rounded-full flex items-center justify-center text-sm font-medium transition-colors
              ${step >= n ? "bg-[#5a4fcf] text-white" : "bg-gray-100 text-gray-400"}`}>
              {n}
            </div>
            <span className="text-[10px] 2xl:text-[14px] font-bold text-gray-400 mt-1 whitespace-nowrap">
              {["Choix", "Inscription", "Paiement"][i]}
            </span>
          </div>
          {i < 2 && <div className={`flex-1 h-1 mx-2 mb-5 ${step > n ? "bg-[#5a4fcf]" : "bg-gray-200"}`} />}
        </div>
      ))}
    </div>
  );

  return (
    <>
      {showSuccess && (
        <SuccessAlert
          onClose={() => { setShowSuccess(false); onClose(); }}
          onContinue={() => { setShowSuccess(false); onClose(); navigate("/dash"); }}
        />
      )}

      {/* MODALE DE SAISIE DE CODE LIÉE À LA NOUVELLE LOGIQUE */}
      {showVerifyModal && (
        <VerificationEmailAlert
          email={email1}
          onClose={() => setShowVerifyModal(false)}
          onVerifySubmit={handleFinalVerification}
        />
      )}

      <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 backdrop-blur-sm p-0 sm:p-4">
        <div className="bg-white w-full sm:max-w-7xl rounded-[2rem] shadow-2xl h-[95vh] overflow-y-auto no-scrollbar">

          {/* ── Étape 3 : Déjà inscrit ── */}
          {step === 3 && dejaInscrit && (
            <div className="p-6 flex flex-col items-center text-center">
              <div className="flex justify-between items-center w-full mb-6">
                <span className="text-sm font-bold text-gray-700 truncate pr-4">"{selectedFormation.titre}"</span>
                <button onClick={onClose} className="text-gray-300 hover:text-gray-500 flex-shrink-0"><X size={18} /></button>
              </div>
              <Stepper />
              <div
                className="flex items-center justify-center rounded-full mb-5"
                style={{ width: 72, height: 72, background: "linear-gradient(135deg,#a5b4fc,#5a4fcf)", boxShadow: "0 8px 24px rgba(90,79,207,0.25)" }}
              >
                <AlertCircle size={34} color="white" />
              </div>
              <h2 className="text-gray-900 text-xl font-bold mb-2">Vous êtes déjà inscrit</h2>
              <p className="text-gray-400 text-sm leading-relaxed mb-8">
                Vous avez déjà soumis une inscription pour la formation{" "}
                <span className="font-semibold text-[#5a4fcf]">"{selectedFormation.titre}"</span>.
                Rendez-vous sur votre tableau de bord pour suivre son statut.
              </p>
              <div className="w-full space-y-3">
                <button
                  onClick={() => { onClose(); navigate("/dash"); }}
                  className="w-full py-3 bg-[#5a4fcf] hover:bg-[#493dbb] text-white rounded-2xl font-bold text-sm transition-all"
                >
                  Voir mon tableau de bord
                </button>
              </div>
            </div>
          )}

          {/* ── Étape 3 : Paiement ── */}
          {step === 3 && !dejaInscrit && (
            <div className="p-10">
              <div className="flex justify-between items-center mb-6">
                <span className="text-sm font-bold text-gray-700 truncate pr-4"></span>
                <button onClick={onClose} className="text-gray-300 hover:text-gray-500"><X size={18} /></button>
              </div>

              <Stepper />

              <p className="text-[10px] 2xl:text-[14px] font-bold uppercase tracking-widest text-gray-400 mb-4">Méthode de paiement</p>
              <p className="text-[10px] 2xl:text-[12px] text-gray-400 mb-4">Vueillez remplir ce formulaire pour effectuer votre paiement</p>

              <div className="flex flex-col md:flex-row gap-10 p-10">
                <div className="flex-1 flex flex-col justify-between">
                  <h2 className="text-lg mb-4 font-bold text-gray-800">Formation sélectionnée: <span className="font-medium text-blue-600">{selectedFormation.titre}</span></h2>
                  <form onSubmit={handleInscriptionSubmit} className="flex flex-col gap-3 h-full">
                    <div>
                      <label className="block text-[9px] 2xl:text-[14px] text-gray-400 mb-1">
                        Votre numéro
                      </label>
                      <input
                        type="text"
                        placeholder="03X XX XXX XX"
                        required
                        className="w-full bg-white border border-gray-100 shadow-sm rounded-xl p-3 text-sm font-bold focus:ring-4 focus:ring-[#5a4fcf]/10 focus:border-[#5a4fcf] outline-none"
                        onChange={(e) => setPaymentData({ ...paymentData, numero_paiement: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="block text-[9px] 2xl:text-[14px] text-gray-400 mb-1">
                        Référence
                      </label>
                      <input
                        type="text"
                        placeholder="Ex: 1234ABCD"
                        required
                        className="w-full bg-white border border-gray-100 shadow-sm rounded-xl p-3 text-sm font-bold focus:ring-4 focus:ring-[#5a4fcf]/10 focus:border-[#5a4fcf] outline-none"
                        onChange={(e) => setPaymentData({ ...paymentData, reference_transaction: e.target.value })}
                      />
                    </div>

                    {error && <p className="text-red-500 text-xs">{error}</p>}

                    <div className="grid grid-cols-2 gap-2 mt-auto pt-4">
                      <button type="button" onClick={() => setStep(2)}
                        className="py-3 bg-gray-100 text-gray-500 text-xs 2xl:text-[16px] rounded-xl hover:bg-gray-200 transition-all uppercase tracking-tighter">
                        Retour
                      </button>
                      <button type="submit" disabled={submitting}
                        className="py-3 bg-[#5a4fcf] text-white text-xs 2xl:text-[16px] rounded-xl shadow-lg hover:bg-[#493dbb] transition-all disabled:bg-gray-300 uppercase tracking-tighter">
                        {submitting ? "Envoi..." : "C o n f i r m e r"}
                      </button>
                    </div>
                  </form>
                </div>
                <div className="flex flex-col gap-3 w-full md:w-[45%]">
                  <div
                    onClick={() => setPaymentData({ ...paymentData, methode: "Mvola" })}
                    className="cursor-pointer flex items-center gap-3 px-3 py-3 rounded-2xl border-2 border-[#5a4fcf] shadow-sm bg-white"
                  >
                    <div className="w-12 h-8 bg-red-500 rounded-lg flex items-center justify-center flex-shrink-0">
                      <span className="text-white text-sm font-black">M</span>
                    </div>
                    <span className="text-sm font-black text-[#5a4fcf]">Mvola</span>
                    <CheckCircle size={15} className="ml-auto text-[#5a4fcf]" />
                  </div>

                  <div className="bg-[#f0eeff] rounded-2xl px-4 py-4 flex flex-col gap-3 flex-1">
                    <div>
                      <p className="text-[9px] 2xl:text-[14px] font-bold text-[#5a4fcf] tracking-widest mb-1">Envoyer vers</p>
                      <p className="text-sm font-black text-gray-800 font-mono">034 70 840 46</p>
                    </div>
                    <div className="border-t border-[#d6cfff] pt-3">
                      <p className="text-[9px] 2xl:text-[14px] font-bold text-[#5a4fcf] tracking-widest mb-1">Montant à payer</p>
                      <p className="text-lg font-black text-gray-900">
                        {selectedFormation.frais?.toLocaleString()}
                        <span className="text-xs text-gray-400 ml-1">Ar</span>
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ── Étapes 1 & 2 ── */}
          {(step === 1 || step === 2) && (
            <div className="p-6 h-full">
              <div className="flex justify-between items-center mb-4 ml-11">
                <span></span>
                <button onClick={onClose} className="text-gray-300 hover:text-gray-500 flex-shrink-0"><X size={18} /></button>
              </div>

              <Stepper />

              {/* ── Étape 1 : Choix de la formation ── */}
              {step === 1 && (
                <div className="flex flex-col justify-between">
                  <div>
                    <h2 className="text-lg font-black text-gray-900 mb-1">Choisir une formation</h2>
                    <p className="text-sm text-gray-400 mb-6">Sélectionnez une formation de votre choix ci-dessous, puis cliquez sur continuer.</p>
                    
                    <div className="space-y-3">
                      <ChoixFormation 
                        activeTab={activeTab} 
                        setActiveTab={setActiveTab}
                        searchTerm={searchTerm}
                        setSearchTerm={setSearchTerm}
                        selectedId={tempSelection?.id}
                        onSelectFormation={(formationSelectionnee) => {
                          setTempSelection(formationSelectionnee);
                        }}
                      />
                    </div>
                  </div>

                  <div className="mt-6 p-4 border-t border-gray-100 flex flex-col sm:flex-row items-center justify-between gap-4 bg-gray-50 rounded-2xl">
                    <p className="text-sm text-gray-600 font-medium">
                      {tempSelection ? (
                        <span>Formation choisie : <strong className="text-[#5a4fcf]">"{tempSelection.titre}"</strong></span>
                      ) : (
                        <span className="text-gray-400 italic">Veuillez sélectionner une formation dans la liste ci-dessus</span>
                      )}
                    </p>
                    <button
                      type="button"
                      disabled={!tempSelection}
                      onClick={handleConfirmFormation}
                      className="w-full sm:w-auto px-8 py-3 bg-[#5a4fcf] hover:bg-[#493dbb] text-white font-bold text-sm rounded-xl transition-all disabled:opacity-50 disabled:bg-gray-300 uppercase tracking-wide"
                    >
                      Continuer →
                    </button>
                  </div>
                </div>
              )}

              {/* ── Étape 2 : Formulaire inscription ── */}
              {step === 2 && (
                <div>
                  <h2 className="text-lg font-black text-gray-900 mb-1">Inscription</h2>
                  <p className="text-sm text-gray-400 mb-6">Veuillez remplir ce formulaire d'inscription, puis cliquez sur s'inscrire.</p>
                  <div className="grid grid-cols-3 gap-6">
                    <form onSubmit={handleSignup} className="space-y-2.5 grid col-span-2">
                      <div className="space-y-2.5 mx-10 py-5 border-2 px-10 rounded-2xl">
                        <div className="grid grid-cols-2 gap-7">
                          <input placeholder="Nom" value={nom} onChange={e => setNom(e.target.value)} required
                            className="border border-gray-200 rounded-xl px-3 py-2.5 text-sm outline-none focus:border-[#5a4fcf] bg-white"/>
                          <input placeholder="Prénom" value={prenom} onChange={e => setPrenom(e.target.value)} required
                            className="border border-gray-200 rounded-xl px-3 py-2.5 text-sm outline-none focus:border-[#5a4fcf] bg-white"/>
                        </div>
                        <div className="grid grid-cols-2 gap-7">
                          <input type="tel" placeholder="Contact (+261...)" value={contact} onChange={e => setContact(e.target.value)} required 
                            className="w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm outline-none focus:border-[#5a4fcf] bg-white"/>
                          <input type="email" placeholder="Email" value={email1} onChange={e => setEmail1(e.target.value)} required
                            className="w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm outline-none focus:border-[#5a4fcf] bg-white"/>
                        </div>
                        <div className="grid grid-cols-2 gap-7">
                          <div>
                            <div className="relative">
                              <input type={showPwd ? "text" : "password"} placeholder="Mot de passe" value={mdp1} onChange={e => setMdp1(e.target.value)} required
                                className="w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm outline-none focus:border-[#5a4fcf] bg-white"/>
                              <button type="button" onClick={() => setShowPwd(!showPwd)}
                                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-300 hover:text-gray-500 text-xs">
                                {showPwd ? "Cacher" : "Voir"}
                              </button>
                            </div>
                            {mdp1 && (
                              <div className="px-1 pt-1 transition-all duration-300">
                                <div className="flex justify-between items-center mb-1">
                                  <span className="text-[10px] uppercase font-black text-gray-400">
                                    Sécurité :
                                  </span>
                                  <span className={`text-[10px] uppercase font-black ${strength?.color.replace('bg-', 'text-')}`}>
                                    {strength?.label}
                                  </span>
                                </div>
                                <div className="h-1.5 w-full bg-gray-100 rounded-full overflow-hidden">
                                  <div
                                    className={`h-full transition-all duration-500 ${strength?.color}`}
                                    style={{ width: `${(strength!.score / 4) * 100}%` }}
                                  />
                                </div>
                              </div>
                            )}
                          </div>
                          <div className="relative">
                            <input type={showPwd1 ? "text" : "password"} placeholder="Confirmer le mot de passe" value={cmdp1} onChange={e => setCmdp1(e.target.value)} required
                              className="w-full border border-gray-200 rounded-xl px-4 py-2.5 text-sm outline-none focus:border-[#5a4fcf] bg-white"/>
                            <button type="button" onClick={() => setShowPwd1(!showPwd1)}
                              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-300 hover:text-gray-500 text-xs">
                              {showPwd1 ? "Cacher" : "Voir"}
                            </button>
                          </div>
                          {error && <p className="text-red-500 text-xs col-span-2">{error}</p>}
                        </div>
                        <div className="flex items-center mt-2 gap-2">
                          <input type="checkbox" className="float-left" required/> <span className="text-xs text-gray-400">J'accepte les <a href="/terms" target="_blank" className="text-[#5a4fcf] hover:underline">conditions d'utilisation</a></span>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-2 mx-10 ">
                        <button type="submit" disabled={submitting}
                          className="w-full py-3 bg-[#5a4fcf] hover:bg-[#493dbb] text-white rounded-xl text-sm font-black transition-all disabled:opacity-70 uppercase tracking-wide">
                          {submitting ? "Inscription..." : "S'inscrire →"}
                        </button>
                        <button type="button" onClick={() => { setStep(1); setError(""); }}
                          className="mt-3 text-xs text-gray-400 hover:text-gray-600 text-center">
                          ← Retour
                        </button>
                      </div>
                    </form>
                    
                    <div className="border-2 p-4 rounded-2xl bg-slate-200 h-fit">
                      <div className="flex flex-col items-center">
                        <img src={logo} alt="Logo" className="w-52 flex justify-center"/>
                      </div>
                      <span className="text-sm font-bold text-gray-700 pr-4 block mt-2">
                        {tempSelection ? `Formation sélectionnée : "${tempSelection.titre}"` : `"${selectedFormation.titre || 'Choisir une formation'}"`}
                      </span>
                      <p className="text-xs text-gray-500 mt-2">Formé par <span className="font-bold text-[#5a4fcf]">{selectedFormation.nom_formateur}</span></p>
                      <div className="flex justify-between mt-2 ml-5">
                        <p>Type: </p> <span className="font-bold text-gray-700 mr-7">{selectedFormation.type}</span>
                      </div>
                      <div className="flex justify-between mt-2 ml-5">
                        <p>Net à payer: </p> <span className="text-sm font-bold text-gray-700 mt-2 mr-7">{selectedFormation.frais ? `${selectedFormation.frais.toLocaleString()} Ar` : "0 Ar"}</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </>
  );
}

// mCJ42SDXFqjcue