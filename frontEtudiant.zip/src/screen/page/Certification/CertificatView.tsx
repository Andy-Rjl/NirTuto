import { motion } from 'framer-motion';
import { ChevronLeft, Download } from 'lucide-react';
import logo from './../../../assets/images/logo-nir-info.png';
import fond from './../../../assets/images/certif.jpg';

interface CertificatViewProps {
  selectedCert: any;
  setViewDetail: (value: boolean) => void;
  handleDownload: () => void;
}

export const CertificatView = ({ selectedCert, setViewDetail, handleDownload }: CertificatViewProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      className="flex flex-col items-center gap-6"
    >
      <div className="w-full flex justify-end">
        <button
          onClick={() => setViewDetail(false)}
          className="flex items-center gap-2 bg-white hover:bg-slate-50 text-slate-600 border border-slate-200 px-4 py-2 font-medium text-xs transition-all shadow-2xs"
        >
          <ChevronLeft size={14} /> Retour à la liste
        </button>
      </div>

      <div className="w-full overflow-x-auto">
        <div
          id="certificat-a-imprimer"
          className="bg-white rounded-none relative overflow-hidden border border-slate-300 mx-auto"
          style={{ aspectRatio: '1.414 / 1', minWidth: '320px', maxWidth: '860px', backgroundImage: `url(${fond})`, backgroundRepeat: 'no-repeat', backgroundSize: 'cover' }}
        >
          {/* <div className="absolute top-0 right-0 w-1/2 h-1/2 bg-[#0056b3]" style={{ clipPath: 'polygon(100% 0, 20% 0, 100% 80%)' }} />
          <div className="absolute bottom-0 left-0 w-1/3 h-1/3 bg-[#0056b3]" style={{ clipPath: 'polygon(0 0, 0% 100%, 100% 100%)' }} /> */}

          <div className="relative p-8 h-full flex flex-col items-center justify-between text-[#1a1a1a]">
            <div className="w-full flex mt-5 justify-center">
              <img src={logo} alt="Logo" className="h-10 sm:h-14 md:h-20 w-auto object-contain" />
            </div>
            <div className="text-center -mt-14">
              <h3 className="text-xl sm:text-3xl md:text-4xl lg:text-[44px] font-serif italic text-slate-800 mb-2">
                Certification de formation
              </h3>
              <div className="w-32 h-[2px] bg-[#0056b3] mx-auto" />
            </div>
            <div className="text-center px-6 space-y-2 w-full -mt-14">
              <p className="text-xs sm:text-sm md:text-base">
                L'organisme <span className="font-bold">Nir'Info</span> atteste le{' '}
                <span className="font-bold">{selectedCert.date_de_delivrance}</span> que
              </p>
              <p className="font-bold text-sm sm:text-xl md:text-2xl text-slate-900">
                {selectedCert.nom} {selectedCert.prenom}{' '}
                <span className="text-xs sm:text-sm font-normal text-slate-600">
                  né le {selectedCert.date_Naissance} à {selectedCert.lieu_Naissance}
                </span>
              </p>
              <p className="text-xs sm:text-sm md:text-base">
                a suivi avec succès la formation{' '}
                <span className="font-bold text-slate-900">{selectedCert.formation}</span>
              </p>
            </div>
            <div className="w-full flex justify-between items-end px-6">
              <div className="text-center mb-24 ml-20">
                <p className="text-[10px] sm:text-xs italic mb-1 text-slate-400">Signature pédagogique</p>
                <div className="w-16 h-[1px] bg-slate-400 mx-auto" />
              </div>
              <div className="text-[10px] sm:text-xs text-blue-600 mr-40 mb-3 font-medium">
                https://tuto-info.com
              </div>
            </div>
          </div>
        </div>
      </div>

      <button
        onClick={handleDownload}
        className="flex items-center gap-2 text-white px-8 py-3.5 bg-slate-800 hover:bg-slate-900 transition-all font-medium text-xs uppercase tracking-widest shadow-2xs"
      >
        <Download size={16} /> Télécharger en PDF
      </button>
    </motion.div>
  );
};