import logo from './../../../assets/images/logo-nir-info.png';

interface Cours {
  id: number;
  titre: string;
  prix: number;
}

interface FactureType {
  numero: string;
  date_inscription: string;
  client: string;
  email: string;
  cours: Cours[];
  total: number;
  statut: "Payé" | "En attente";
  methode?: string;
}

interface FactureDetailProps {
  selectedFacture: FactureType;
  onBack: () => void;
}

const FactureDetail = ({ selectedFacture, onBack }: FactureDetailProps) => {
  return (
    <>
      {/* Boutons header (retour + imprimer) */}
      <div className="flex w-full sm:w-auto gap-2">
        <button
          onClick={onBack}
          className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2 border border-slate-300 rounded-xl text-slate-700 hover:bg-slate-50 text-sm font-bold transition-all"
        >
          ← Liste
        </button>
        <button
          onClick={() => window.print()}
          className="flex-1 sm:flex-none bg-blue-600 text-white px-5 py-2 rounded-xl hover:bg-blue-700 transition-colors flex items-center justify-center gap-2 shadow-lg shadow-blue-100 text-sm font-bold"
        >
          Imprimer
        </button>
      </div>

      {/* DÉTAIL FACTURE */}
      <div id='facture-a-imprimer' className="max-w-4xl mx-auto mb-10 mt-6">
        <div className="overflow-x-auto">
          <div
            className="bg-white shadow-xl border border-slate-200 flex flex-col p-6 sm:p-8 md:p-12 text-slate-800 font-sans relative overflow-hidden"
            style={{ minWidth: '320px' }}
          >
            {/* HEADER FACTURE */}
            <div className="relative mb-6 sm:mb-8">
              <div className="flex flex-col sm:flex-row sm:items-center gap-3 sm:gap-4 mb-4">
                <img src={logo} alt="Logo Nir'Info" className="h-10 sm:h-14 md:h-16 w-auto object-contain" />
                <h1 className="text-xl sm:text-3xl md:text-4xl font-bold text-[#1e3a8a] tracking-tight">
                  REÇU DE PAIEMENT
                </h1>
              </div>
              <div className="h-[2px] bg-[#1e3a8a] w-full mb-4 sm:mb-6" />

              {/* Date + N° reçu */}
              <div className="flex flex-col sm:flex-row justify-between gap-2 sm:gap-0 text-xs sm:text-sm">
                <div className="flex gap-2 flex-wrap">
                  <span className="font-semibold">Date de paiement :</span>
                  <span className="border-b border-slate-400 min-w-[120px] sm:min-w-[150px]">
                    {selectedFacture.date_inscription || "12 Mars 2026"}
                  </span>
                </div>
                <div className="flex gap-2 flex-wrap">
                  <span className="font-semibold">N° de reçu :</span>
                  <span className="border-b border-slate-400 min-w-[120px] sm:min-w-[150px]">
                    {selectedFacture.numero}
                  </span>
                </div>
              </div>
              <div className="h-[2px] bg-[#1e3a8a] w-full mt-4 sm:mt-6" />
            </div>

            {/* INFOS CLIENT */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 sm:gap-12 mb-6 sm:mb-10 text-xs sm:text-sm">
              <div>
                <h3 className="font-bold text-base sm:text-lg mb-2">De :</h3>
                <div className="space-y-1">
                  <p><span className="font-semibold">Nom:</span> Tuto-Info Madagascar</p>
                  <p><span className="font-semibold">Contact:</span> +261 34 70 840 46</p>
                  <p><span className="font-semibold">Adresse:</span> Ampefiloha, Antananarivo</p>
                </div>
              </div>
              <div>
                <h3 className="font-bold text-base sm:text-lg mb-2">Facturé à :</h3>
                <div className="space-y-1">
                  <p><span className="font-semibold">Nom:</span> {selectedFacture.client}</p>
                  <p><span className="font-semibold">Contact:</span> {selectedFacture.email}</p>
                  <p><span className="font-semibold">Adresse:</span> Madagascar</p>
                </div>
              </div>
            </div>

            <div className="h-[2px] bg-[#1e3a8a] w-full mb-4 sm:mb-6" />

            {/* TABLEAU ARTICLES */}
            <div className="overflow-x-auto">
              <table className="w-full border-collapse border border-slate-300 text-xs sm:text-sm">
                <thead>
                  <tr className="text-left border-b border-slate-300">
                    <th className="p-2 sm:p-3 border-r border-slate-300 w-1/2">Désignation</th>
                    <th className="p-2 sm:p-3 border-r border-slate-300 text-center">Accès</th>
                    <th className="p-2 sm:p-3 border-r border-slate-300 text-center">Prix Unitaire</th>
                    <th className="p-2 sm:p-3 text-center">Total</th>
                  </tr>
                </thead>
                <tbody>
                  {selectedFacture.cours.map((item) => (
                    <tr key={item.id} className="border-b border-slate-200">
                      <td className="p-2 sm:p-3 border-r border-slate-300 font-medium">{item.titre}</td>
                      <td className="p-2 sm:p-3 border-r border-slate-300 text-center">1</td>
                      <td className="p-2 sm:p-3 border-r border-slate-300 text-center">{item.prix.toLocaleString()} AR</td>
                      <td className="p-2 sm:p-3 text-center">{item.prix.toLocaleString()} AR</td>
                    </tr>
                  ))}
                  {[...Array(Math.max(0, 6 - selectedFacture.cours.length))].map((_, i) => (
                    <tr key={`empty-${i}`} className="border-b border-slate-200 h-8 sm:h-10">
                      <td className="border-r border-slate-300" />
                      <td className="border-r border-slate-300" />
                      <td className="border-r border-slate-300" />
                      <td />
                    </tr>
                  ))}
                </tbody>
              </table>

              {/* TOTAUX */}
              <div className="flex justify-end mt-0">
                <table className="w-full sm:w-1/2 border-l border-b border-r border-slate-300 text-xs sm:text-sm">
                  <tbody>
                    <tr>
                      <td className="p-2 border-r border-slate-300 font-semibold">Sous-total</td>
                      <td className="p-2 text-right">{selectedFacture.total.toLocaleString()} AR</td>
                    </tr>
                    <tr>
                      <td className="p-2 border-r border-slate-300 font-semibold flex justify-between">
                        Taux de taxe <span>0%</span>
                      </td>
                      <td className="p-2 text-right">0 AR</td>
                    </tr>
                    <tr className="bg-slate-50">
                      <td className="p-2 border-r border-slate-300 font-bold">Total Payé</td>
                      <td className="p-2 text-right font-bold">{selectedFacture.total.toLocaleString()} AR</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            {/* FOOTER FACTURE */}
            <div className="mt-8 sm:mt-12 flex flex-col sm:flex-row justify-between items-start sm:items-end gap-6 text-xs sm:text-sm">
              <div>
                <h4 className="font-bold mb-2 underline">Mode de paiement :</h4>
                <p>Mobile Money</p>
                <p className="mt-4 text-xs italic text-slate-500">
                  Merci d'avoir choisi Tuto-Info Madagascar !<br />
                  Au plaisir de vous revoir bientôt.
                </p>
              </div>
              <div className="text-center">
                <h4 className="font-bold mb-8 sm:mb-10">Autorisé par :</h4>
                <div className="w-48 sm:w-64 border-t border-slate-400 pt-2 text-xs sm:text-sm">
                  Responsable Tuto-Info
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </>
  );
};

export default FactureDetail;